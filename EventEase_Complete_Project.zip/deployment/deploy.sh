#!/bin/bash
# Deployment Script for EventEase